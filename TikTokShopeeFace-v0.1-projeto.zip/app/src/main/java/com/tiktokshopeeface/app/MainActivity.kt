package com.tiktokshopeeface.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { ShopApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopApp() {
    var profile by remember { mutableStateOf("Mike") }
    Scaffold(topBar = { TopAppBar(title = { Text("TikTokShopeeFace") }) }) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Text("Perfil ativo", style = MaterialTheme.typography.labelLarge) }
            item {
                OutlinedTextField(
                    value = profile,
                    onValueChange = { profile = it },
                    label = { Text("Nome do perfil") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item { PlatformCard("TikTok Shop", "Postar • Agenda • Histórico") }
            item { PlatformCard("Shopee Vídeo", "Postar • Agenda • Histórico") }
            item { PlatformCard("Facebook", "Página • Reels • Agenda") }
            item { HorizontalDivider() }
            item { Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Biblioteca de vídeos") } }
            item { OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Agenda geral") } }
            item { OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Histórico") } }
            item { Text("v0.1 • Base para testes") }
        }
    }
}

@Composable
fun PlatformCard(name: String, subtitle: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(name, style = MaterialTheme.typography.titleLarge)
            Text(subtitle)
            Button(onClick = {}) { Text("Abrir") }
        }
    }
}
